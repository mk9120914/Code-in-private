import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function Confirmation() {
  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Order Confirmed</CardTitle>
          <CardDescription>Thank you for your order!</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Your food will be delivered to your seat shortly.</p>
          <p>Enjoy your meal!</p>
        </CardContent>
        <CardFooter>
          <Link href="/" className="w-full">
            <Button className="w-full">Back to Menu</Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

