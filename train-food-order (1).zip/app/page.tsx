"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ShoppingCart, Plus, Minus } from "lucide-react"
import Link from "next/link"

interface MenuItem {
  id: number
  name: string
  description: string
  price: number
}

const menuItems: MenuItem[] = [
  { id: 1, name: "Sandwich", description: "Fresh and delicious", price: 5.99 },
  { id: 2, name: "Salad", description: "Healthy and crispy", price: 4.99 },
  { id: 3, name: "Pasta", description: "Italian style", price: 7.99 },
  { id: 4, name: "Burger", description: "Juicy and tasty", price: 6.99 },
  { id: 5, name: "Pizza", description: "Cheesy goodness", price: 8.99 },
]

export default function Home() {
  const [cart, setCart] = useState<{ item: MenuItem; quantity: number }[]>([])

  const addToCart = (item: MenuItem) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((cartItem) => cartItem.item.id === item.id)
      if (existingItem) {
        return prevCart.map((cartItem) =>
          cartItem.item.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      }
      return [...prevCart, { item, quantity: 1 }]
    })
  }

  const removeFromCart = (itemId: number) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((cartItem) => cartItem.item.id === itemId)
      if (existingItem && existingItem.quantity > 1) {
        return prevCart.map((cartItem) =>
          cartItem.item.id === itemId ? { ...cartItem, quantity: cartItem.quantity - 1 } : cartItem,
        )
      }
      return prevCart.filter((cartItem) => cartItem.item.id !== itemId)
    })
  }

  const totalPrice = cart.reduce((total, cartItem) => total + cartItem.item.price * cartItem.quantity, 0)

  return (
    <main className="flex flex-col md:flex-row gap-8">
      <section className="flex-1">
        <h2 className="text-2xl font-semibold mb-4">Menu</h2>
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {menuItems.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <CardTitle>{item.name}</CardTitle>
                <CardDescription>{item.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">${item.price.toFixed(2)}</p>
              </CardContent>
              <CardFooter>
                <Button onClick={() => addToCart(item)}>Add to Cart</Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
      <section className="w-full md:w-80">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart />
              <span>Your Cart</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {cart.length === 0 ? (
              <p>Your cart is empty</p>
            ) : (
              <ul className="space-y-2">
                {cart.map((cartItem) => (
                  <li key={cartItem.item.id} className="flex items-center justify-between">
                    <span>{cartItem.item.name}</span>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => removeFromCart(cartItem.item.id)}>
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span>{cartItem.quantity}</span>
                      <Button variant="outline" size="icon" onClick={() => addToCart(cartItem.item)}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
          <CardFooter className="flex flex-col items-start gap-4">
            <div className="flex justify-between w-full">
              <span className="font-semibold">Total:</span>
              <span className="font-bold">${totalPrice.toFixed(2)}</span>
            </div>
            <Link href="/checkout" className="w-full">
              <Button className="w-full" disabled={cart.length === 0}>
                Proceed to Checkout
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </section>
    </main>
  )
}

